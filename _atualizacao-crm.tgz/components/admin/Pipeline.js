'use client';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { sb } from '@/lib/admin/cliente';
import { ETAPAS } from '@/lib/admin/opcoes';
import { CANAIS, dataCurta, dataHora, deLocal, fone, paraLocal, soNumeros, STATUS_VISITA } from '@/lib/admin/ia';
import { Conversa } from './Atendimentos';
import { NovaVisita } from './Agenda';

const COLS = 'id,nome,whatsapp,email,objetivo,regioes,perfil,prazo,motivacao,faixa_investimento,pagamento,tem_imovel_para_vender,decisores,outro_corretor,imoveis_interesse,pontuacao,etapa,motivo_perda,proxima_acao,proxima_acao_em,origem,notas,canal,criado_em,atualizado_em';
const ATIVAS = ETAPAS.filter(([v]) => !['venda', 'perdido'].includes(v));
const rotEtapa = (v) => (ETAPAS.find((e) => e[0] === v) || [v, v])[1];
const canalDe = (l) => l.canal || l.origem?.canal || (l.origem?.utm_source ? `anúncio (${l.origem.utm_source})` : 'site');

export default function Pipeline({ abrirId, aoAbrir }) {
  const [leads, setLeads] = useState(null);
  const [erro, setErro] = useState('');
  const [vista, setVista] = useState('quadro');
  const [busca, setBusca] = useState('');
  const [mostrarFechados, setMostrarFechados] = useState(false);
  const [aberto, setAberto] = useState(null);

  const carregar = useCallback(async () => {
    const { data, error } = await sb().from('leads').select(COLS).order('atualizado_em', { ascending: false, nullsFirst: false }).limit(500);
    if (error) setErro(error.message); else setLeads(data);
  }, []);
  useEffect(() => { carregar(); }, [carregar]);
  useEffect(() => {
    if (abrirId && leads) { const l = leads.find((x) => x.id === abrirId); if (l) setAberto(l); aoAbrir?.(null); }
  }, [abrirId, leads, aoAbrir]);

  const vistos = useMemo(() => (leads || []).filter((l) => !busca || `${l.nome} ${l.whatsapp} ${l.email} ${(l.imoveis_interesse || []).join(' ')}`.toLowerCase().includes(busca.toLowerCase())), [leads, busca]);
  const colunas = mostrarFechados ? ETAPAS : ATIVAS;
  const hoje = Date.now();
  const atrasadas = (leads || []).filter((l) => l.proxima_acao_em && Date.parse(l.proxima_acao_em) < hoje && !['venda', 'perdido'].includes(l.etapa));

  const mover = async (l, etapa) => {
    setLeads((x) => x.map((y) => (y.id === l.id ? { ...y, etapa } : y)));
    const { error } = await sb().from('leads').update({ etapa, atualizado_em: new Date().toISOString() }).eq('id', l.id);
    if (error) setErro(error.message);
  };

  if (aberto) return <Lead lead={aberto} aoFechar={(mudou) => { setAberto(null); if (mudou) carregar(); }} />;

  return (
    <section className="adm-pagina adm-larga">
      <div className="adm-cabeca">
        <div>
          <h1>Pipeline</h1>
          {leads && <p className="adm-sub">{leads.filter((l) => !['venda', 'perdido'].includes(l.etapa)).length} em andamento{atrasadas.length ? ` · ${atrasadas.length} com ação atrasada` : ''}</p>}
        </div>
        <button className="adm-btn adm-primario" onClick={() => setAberto({ etapa: 'novo', canal: 'WhatsApp' })}>+ Novo lead</button>
      </div>
      <div className="adm-filtros">
        <input type="search" placeholder="Buscar por nome, telefone ou código do imóvel" value={busca} onChange={(e) => setBusca(e.target.value)} />
        <div className="adm-seg">
          <button className={vista === 'quadro' ? 'on' : ''} onClick={() => setVista('quadro')}>Quadro</button>
          <button className={vista === 'lista' ? 'on' : ''} onClick={() => setVista('lista')}>Lista</button>
        </div>
      </div>
      {erro && <p className="adm-erro">{erro}</p>}
      {!leads ? <p className="adm-sub">Carregando…</p> : vista === 'quadro' ? (
        <>
          <div className="adm-quadro">
            {colunas.map(([v, n]) => {
              const itens = vistos.filter((l) => (l.etapa || 'novo') === v);
              return (
                <div key={v} className="adm-coluna">
                  <p className="adm-coluna-tit">{n} <span>{itens.length}</span></p>
                  {itens.map((l) => <CartaoLead key={l.id} l={l} aoAbrir={() => setAberto(l)} aoMover={(e) => mover(l, e)} />)}
                </div>
              );
            })}
          </div>
          <label className="adm-check"><input type="checkbox" checked={mostrarFechados} onChange={(e) => setMostrarFechados(e.target.checked)} /> Mostrar vendas e perdidos</label>
        </>
      ) : (
        <ul className="adm-lista">
          {vistos.map((l) => (
            <li key={l.id}>
              <button onClick={() => setAberto(l)}>
                <span className="adm-info">
                  <b>{l.nome || 'Sem nome'} {l.pontuacao && <span className={`adm-nota-lead n-${l.pontuacao}`}>{l.pontuacao}</span>}</b>
                  <small>{rotEtapa(l.etapa || 'novo')} · {canalDe(l)} · {fone(l.whatsapp) || 'sem WhatsApp'}</small>
                  {l.proxima_acao && <small>Próximo: {l.proxima_acao}{l.proxima_acao_em ? ` (${dataCurta(l.proxima_acao_em)})` : ''}</small>}
                </span>
                <small className="adm-sub">{dataCurta(l.atualizado_em || l.criado_em)}</small>
              </button>
            </li>
          ))}
          {!vistos.length && <li className="adm-sub" style={{ padding: 16 }}>Nenhum lead aqui.</li>}
        </ul>
      )}
    </section>
  );
}

function CartaoLead({ l, aoAbrir, aoMover }) {
  const atrasada = l.proxima_acao_em && Date.parse(l.proxima_acao_em) < Date.now();
  return (
    <div className="adm-cartao">
      <button className="adm-cartao-corpo" onClick={aoAbrir}>
        <b>{l.nome || 'Sem nome'} {l.pontuacao && <span className={`adm-nota-lead n-${l.pontuacao}`}>{l.pontuacao}</span>}</b>
        <small>{canalDe(l)} · {dataCurta(l.criado_em)}</small>
        {(l.faixa_investimento || l.regioes?.length) && <small>{[l.faixa_investimento, (l.regioes || []).slice(0, 2).join(', ')].filter(Boolean).join(' · ')}</small>}
        {l.proxima_acao && <small className={atrasada ? 'adm-atrasada' : ''}>→ {l.proxima_acao}{l.proxima_acao_em ? ` · ${dataCurta(l.proxima_acao_em)}` : ''}</small>}
      </button>
      <div className="adm-cartao-pe">
        <select value={l.etapa || 'novo'} onChange={(e) => aoMover(e.target.value)} aria-label="Mover etapa">
          {ETAPAS.map(([v, n]) => <option key={v} value={v}>{n}</option>)}
        </select>
        {l.whatsapp && <a className="adm-zap" href={`https://wa.me/${l.whatsapp}`} target="_blank" rel="noopener" aria-label="WhatsApp">WhatsApp</a>}
      </div>
    </div>
  );
}

function Lead({ lead, aoFechar }) {
  const novo = !lead.id;
  const [f, setF] = useState({
    ...lead, regioesTxt: (lead.regioes || []).join(', '), interesseTxt: (lead.imoveis_interesse || []).join(', '),
    proximaEm: paraLocal(lead.proxima_acao_em), whatsTxt: fone(lead.whatsapp),
  });
  const [msg, setMsg] = useState('');
  const [salvando, setSalvando] = useState(false);
  const [mudou, setMudou] = useState(false);
  const [visitas, setVisitas] = useState([]);
  const [novaVisita, setNovaVisita] = useState(false);
  const set = (k) => (e) => { setF({ ...f, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value }); };

  const carregarVisitas = useCallback(() => {
    if (!lead.id) return;
    sb().from('visitas').select('id,inicio,status,imovel_codigo,observacoes').eq('lead_id', lead.id).order('inicio', { ascending: false }).then(({ data }) => setVisitas(data || []));
  }, [lead.id]);
  useEffect(() => { carregarVisitas(); }, [carregarVisitas]);

  const salvar = async () => {
    if (!String(f.nome || '').trim()) { setMsg('Coloque pelo menos o nome.'); return; }
    setSalvando(true); setMsg('');
    const lista = (t) => String(t || '').split(',').map((x) => x.trim()).filter(Boolean);
    const dados = {
      nome: f.nome.trim(), whatsapp: soNumeros(f.whatsTxt) || null, email: f.email || null, etapa: f.etapa || 'novo',
      pontuacao: f.pontuacao || null, objetivo: f.objetivo || null, regioes: lista(f.regioesTxt), perfil: f.perfil || null,
      prazo: f.prazo || null, faixa_investimento: f.faixa_investimento || null, pagamento: f.pagamento || null,
      imoveis_interesse: lista(f.interesseTxt).map((x) => x.toUpperCase()), proxima_acao: f.proxima_acao || null,
      proxima_acao_em: deLocal(f.proximaEm), notas: f.notas || null, canal: f.canal || null,
      motivo_perda: f.etapa === 'perdido' ? f.motivo_perda || null : null, atualizado_em: new Date().toISOString(),
    };
    const q = novo ? sb().from('leads').insert(dados).select('id').single() : sb().from('leads').update(dados).eq('id', lead.id).select('id').single();
    const { error } = await q;
    setSalvando(false);
    if (error) { setMsg('Não salvou: ' + error.message); return; }
    if (novo) { aoFechar(true); return; }
    setMudou(true); setMsg('Salvo.');
  };
  const excluir = async () => {
    if (!confirm('Excluir este lead e o histórico de visitas dele? Isso não tem volta.')) return;
    await sb().from('visitas').delete().eq('lead_id', lead.id);
    const { error } = await sb().from('leads').delete().eq('id', lead.id);
    if (error) setMsg('Não excluiu: ' + error.message); else aoFechar(true);
  };

  return (
    <section className="adm-pagina adm-editor">
      <button className="adm-link" onClick={() => aoFechar(mudou)}>← Voltar ao pipeline</button>
      <div className="adm-cabeca">
        <h1>{novo ? 'Novo lead' : f.nome || 'Lead'}</h1>
        {f.whatsapp && <a className="adm-btn adm-whats" href={`https://wa.me/${f.whatsapp}`} target="_blank" rel="noopener">WhatsApp</a>}
      </div>

      <div className="adm-bloco">
        <div className="adm-grade2">
          <label className="adm-campo"><span>Etapa</span><select value={f.etapa || 'novo'} onChange={set('etapa')}>{ETAPAS.map(([v, n]) => <option key={v} value={v}>{n}</option>)}</select></label>
          <label className="adm-campo"><span>Nota</span><select value={f.pontuacao || ''} onChange={set('pontuacao')}><option value="">Sem nota</option><option value="A">A · compra em até 3 meses</option><option value="B">B · 3 a 6 meses</option><option value="C">C · mais de 6 meses</option><option value="D">D · fora do perfil</option></select></label>
        </div>
        {f.etapa === 'perdido' && <label className="adm-campo"><span>Motivo da perda</span><input value={f.motivo_perda || ''} onChange={set('motivo_perda')} /></label>}
        <div className="adm-grade2">
          <label className="adm-campo"><span>Próxima ação</span><input placeholder="Ex.: mandar curadoria" value={f.proxima_acao || ''} onChange={set('proxima_acao')} /></label>
          <label className="adm-campo"><span>Quando</span><input type="datetime-local" value={f.proximaEm} onChange={set('proximaEm')} /></label>
        </div>
      </div>

      <div className="adm-bloco">
        <h2>Contato</h2>
        <div className="adm-grade2">
          <label className="adm-campo"><span>Nome</span><input value={f.nome || ''} onChange={set('nome')} /></label>
          <label className="adm-campo"><span>WhatsApp</span><input type="tel" value={f.whatsTxt || ''} onChange={set('whatsTxt')} /></label>
          <label className="adm-campo"><span>E-mail</span><input type="email" value={f.email || ''} onChange={set('email')} /></label>
          <label className="adm-campo"><span>Canal</span>
            <select value={f.canal || ''} onChange={set('canal')}><option value="">{lead.origem?.canal || 'Não informado'}</option>{CANAIS.map((c) => <option key={c}>{c}</option>)}</select>
          </label>
        </div>
        {lead.origem?.utm_source && <p className="adm-sub">Veio de anúncio: {[lead.origem.utm_source, lead.origem.utm_campaign].filter(Boolean).join(' · ')}</p>}
      </div>

      <div className="adm-bloco">
        <h2>O que procura</h2>
        <div className="adm-grade2">
          <label className="adm-campo"><span>Objetivo</span><input placeholder="morar ou investir" value={f.objetivo || ''} onChange={set('objetivo')} /></label>
          <label className="adm-campo"><span>Faixa de investimento</span><input value={f.faixa_investimento || ''} onChange={set('faixa_investimento')} /></label>
          <label className="adm-campo"><span>Regiões (separe por vírgula)</span><input value={f.regioesTxt} onChange={set('regioesTxt')} /></label>
          <label className="adm-campo"><span>Prazo</span><input value={f.prazo || ''} onChange={set('prazo')} /></label>
          <label className="adm-campo"><span>Pagamento</span><input value={f.pagamento || ''} onChange={set('pagamento')} /></label>
          <label className="adm-campo"><span>Imóveis de interesse (códigos)</span><input placeholder="AC-0019, AC-0004" value={f.interesseTxt} onChange={set('interesseTxt')} /></label>
        </div>
        <label className="adm-campo"><span>Perfil da família</span><input value={f.perfil || ''} onChange={set('perfil')} /></label>
        <label className="adm-campo"><span>Suas anotações</span><textarea rows={4} value={f.notas || ''} onChange={set('notas')} /></label>
      </div>

      {!novo && (
        <div className="adm-bloco">
          <div className="adm-cabeca"><h2>Visitas</h2><button className="adm-btn" onClick={() => setNovaVisita(true)}>+ Agendar visita</button></div>
          {!visitas.length && <p className="adm-sub">Nenhuma visita ainda.</p>}
          {visitas.map((v) => {
            const [rot, cls] = STATUS_VISITA[v.status] || [v.status, ''];
            return <p key={v.id} className="adm-visita-mini"><span>{dataHora(v.inicio)} · {v.imovel_codigo || 'imóvel a definir'}</span><span className={`adm-status ${cls}`}>{rot}</span></p>;
          })}
          {novaVisita && <NovaVisita leadInicial={lead} aoFechar={(m) => { setNovaVisita(false); if (m) { carregarVisitas(); setMudou(true); } }} />}
        </div>
      )}

      {!novo && (
        <div className="adm-bloco">
          <h2>Conversas no chat</h2>
          <Conversa leadId={lead.id} />
        </div>
      )}

      <div className="adm-barra">
        <div className="adm-acoes">
          {msg && <span className="adm-msg">{msg}</span>}
          {!novo && <button className="adm-link" onClick={excluir}>Excluir</button>}
          <button className="adm-btn adm-primario" disabled={salvando} onClick={salvar}>{salvando ? 'Salvando…' : novo ? 'Criar lead' : 'Salvar'}</button>
        </div>
      </div>
    </section>
  );
}
